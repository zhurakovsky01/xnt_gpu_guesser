#!/bin/bash

source h-manifest.conf
source $CUSTOM_CONFIG_FILENAME
APPNMAE=$CUSTOM_NAME
APP_PATH=./$APPNMAE

# Останавливаем предыдущий процесс
pkill -9 $APPNMAE

# Запускаем майнер в фоне
$APP_PATH -p $CUSTOM_URL -w $ACCOUNT $CUSTOM_USER_CONFIG >>${CUSTOM_LOG_BASENAME}.log 2>&1 &

# Отображаем команду для проверки
echo "$APP_PATH -p $CUSTOM_URL -w $ACCOUNT $CUSTOM_USER_CONFIG >> ${CUSTOM_LOG_BASENAME}.log 2>&1"

# Автоматически выводим последние 100 строк и следим за логом
tail -f /hive/miners/custom/xntprover/xntprover.log -n 100
